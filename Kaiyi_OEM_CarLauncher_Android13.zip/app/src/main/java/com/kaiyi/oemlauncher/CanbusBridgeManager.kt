package com.kaiyi.oemlauncher

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import java.io.File
import java.io.FileOutputStream
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

data class VehicleCanbusState(
    val doorFrontLeftOpen: Boolean = false,
    val doorFrontRightOpen: Boolean = false,
    val doorRearLeftOpen: Boolean = false,
    val doorRearRightOpen: Boolean = false,
    val trunkOpen: Boolean = false,
    val hoodOpen: Boolean = false,
    val tpmsFrontLeftPsi: Float = 33.5f,
    val tpmsFrontRightPsi: Float = 33.5f,
    val tpmsRearLeftPsi: Float = 33.0f,
    val tpmsRearRightPsi: Float = 33.0f,
    val tpmsFrontLeftAlert: Boolean = false,
    val tpmsFrontRightAlert: Boolean = false,
    val tpmsRearLeftAlert: Boolean = false,
    val tpmsRearRightAlert: Boolean = false,
    val lastUpdatedMs: Long = 0L
) {
    fun anyDoorOpen(): Boolean =
        doorFrontLeftOpen || doorFrontRightOpen || doorRearLeftOpen || doorRearRightOpen || trunkOpen || hoodOpen

    fun anyTpmsAlert(): Boolean =
        tpmsFrontLeftAlert || tpmsFrontRightAlert || tpmsRearLeftAlert || tpmsRearRightAlert
}

data class CanbusLogEntry(
    val timestamp: String,
    val direction: String, // "RX" or "TX"
    val action: String,
    val detail: String
)

/**
 * Módulo Puente CANBUS Bidireccional:
 * - Escucha broadcasts estándar de radios Android (TS, SYU, TW, Microntek, Android CANBUS)
 * - Actualiza alertas de puertas y presión de neumáticos (TPMS)
 * - Envía BroadcastIntents y/o tramas hexadecimales seriales/MCU para cambiar el tema del clúster
 */
object CanbusBridgeManager {

    private val STANDARD_CANBUS_ACTIONS = listOf(
        "com.ts.canbus",
        "com.ts.canbus.DATA",
        "com.ts.canbus.ACTION_CANBUS_DATA",
        "com.syu.canbus",
        "com.syu.canbus.ACTION_CANBUS_DATA",
        "com.syu.ms.canbus",
        "com.tw.canbus",
        "com.tw.canbus.REPORT",
        "com.microntek.canbus",
        "com.microntek.canbus.display",
        "android.intent.action.CANBUS"
    )

    private val timeFormat = SimpleDateFormat("HH:mm:ss", Locale.getDefault())
    private val listeners = LinkedHashSet<(VehicleCanbusState) -> Unit>()
    private val logListeners = LinkedHashSet<(List<CanbusLogEntry>) -> Unit>()
    private val logBuffer = ArrayList<CanbusLogEntry>(MAX_LOGS)

    private var currentState = VehicleCanbusState()
    private var receiver: BroadcastReceiver? = null
    private var isRegistered = false

    fun getCurrentState(): VehicleCanbusState = currentState

    fun getLogs(): List<CanbusLogEntry> = synchronized(logBuffer) { logBuffer.toList() }

    fun clearLogs() {
        synchronized(logBuffer) {
            logBuffer.clear()
        }
        notifyLogListeners()
    }

    fun addStateListener(listener: (VehicleCanbusState) -> Unit) {
        listeners.add(listener)
        listener(currentState)
    }

    fun removeStateListener(listener: (VehicleCanbusState) -> Unit) {
        listeners.remove(listener)
    }

    fun addLogListener(listener: (List<CanbusLogEntry>) -> Unit) {
        logListeners.add(listener)
        listener(getLogs())
    }

    fun removeLogListener(listener: (List<CanbusLogEntry>) -> Unit) {
        logListeners.remove(listener)
    }

    fun startListening(context: Context) {
        if (isRegistered) return
        val appContext = context.applicationContext
        val filter = IntentFilter().apply {
            STANDARD_CANBUS_ACTIONS.forEach { addAction(it) }
        }

        val dynamicReceiver = object : BroadcastReceiver() {
            override fun onReceive(ctx: Context?, intent: Intent?) {
                if (intent == null) return
                processIncomingBroadcast(intent)
            }
        }

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            appContext.registerReceiver(dynamicReceiver, filter, Context.RECEIVER_EXPORTED)
        } else {
            @Suppress("DEPRECATION")
            appContext.registerReceiver(dynamicReceiver, filter)
        }
        receiver = dynamicReceiver
        isRegistered = true
    }

    fun stopListening(context: Context) {
        if (!isRegistered) return
        runCatching {
            receiver?.let { context.applicationContext.unregisterReceiver(it) }
        }
        receiver = null
        isRegistered = false
    }

    fun processIncomingBroadcast(intent: Intent) {
        val action = intent.action ?: "unknown.canbus"
        val extras = intent.extras
        val detailSummary = summarizeExtras(extras)

        appendLog(
            CanbusLogEntry(
                timestamp = timeFormat.format(Date()),
                direction = "RX",
                action = action,
                detail = detailSummary
            )
        )

        if (extras != null) {
            val updated = parseVehicleExtras(currentState, extras)
            if (updated != currentState) {
                currentState = updated
                notifyStateListeners()
            }
        }
    }

    fun simulateDoorAndTpmsAlert() {
        val nextFl = !currentState.doorFrontLeftOpen
        val nextAlert = nextFl
        currentState = currentState.copy(
            doorFrontLeftOpen = nextFl,
            doorRearRightOpen = nextFl,
            tpmsFrontLeftPsi = if (nextAlert) 25.2f else 33.5f,
            tpmsFrontLeftAlert = nextAlert,
            lastUpdatedMs = System.currentTimeMillis()
        )
        appendLog(
            CanbusLogEntry(
                timestamp = timeFormat.format(Date()),
                direction = "RX",
                action = "com.ts.canbus.SIMULATED",
                detail = "door_fl=$nextFl, door_rr=$nextFl, tpms_fl=${currentState.tpmsFrontLeftPsi} PSI"
            )
        )
        notifyStateListeners()
    }

    /**
     * Envía comando bidireccional al clúster / MCU según la configuración guardada en LauncherPrefs.
     */
    fun sendClusterThemeCommand(context: Context, prefs: LauncherPrefs, mode: ClusterThemeMode): String {
        prefs.setActiveClusterTheme(mode)
        val config = prefs.getClusterCommandConfig(mode)

        val broadcastIntent = Intent(config.broadcastAction).apply {
            if (config.targetPackage.isNotBlank()) {
                setPackage(config.targetPackage)
            }
            if (config.extraKey.isNotBlank()) {
                val intVal = config.extraValue.toIntOrNull()
                if (intVal != null) {
                    putExtra(config.extraKey, intVal)
                } else {
                    putExtra(config.extraKey, config.extraValue)
                }
            }
            val parsedHex = parseHexBytes(config.hexPayload)
            if (parsedHex.isNotEmpty()) {
                putExtra("data", parsedHex)
                putExtra("cmd_bytes", parsedHex)
            }
            addFlags(Intent.FLAG_INCLUDE_STOPPED_PACKAGES)
        }

        val broadcastOk = runCatching {
            context.sendBroadcast(broadcastIntent)
            true
        }.getOrDefault(false)

        val serialStatus = writeHexToSerialIfAvailable(config.serialPortPath, config.hexPayload)

        val txDetail = buildString {
            append("${mode.displayName} -> ")
            append("Broadcast(${if (broadcastOk) "OK" else "ERR"} ${config.extraKey}=${config.extraValue})")
            if (config.serialPortPath.isNotBlank()) {
                append(" | MCU(${config.serialPortPath}: $serialStatus)")
            }
        }

        appendLog(
            CanbusLogEntry(
                timestamp = timeFormat.format(Date()),
                direction = "TX",
                action = config.broadcastAction,
                detail = txDetail
            )
        )

        return txDetail
    }

    fun scanInstalledCanbusPackages(context: Context): List<String> {
        val pm = context.packageManager
        val packages = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            pm.getInstalledPackages(PackageManager.PackageInfoFlags.of(0L))
        } else {
            @Suppress("DEPRECATION")
            pm.getInstalledPackages(0)
        }

        val keywords = listOf("canbus", "syu", "ts.", "microntek", "tw.", "carinfo", "carsetting", "mainui", "kaiyi")
        return packages
            .map { it.packageName }
            .filter { pkg -> keywords.any { kw -> pkg.lowercase().contains(kw) } }
            .sorted()
    }

    private fun writeHexToSerialIfAvailable(portPath: String, hexString: String): String {
        if (portPath.isBlank() || hexString.isBlank()) return "Omitido"
        val bytes = parseHexBytes(hexString)
        if (bytes.isEmpty()) return "Hex inválido"
        val device = File(portPath)
        if (!device.exists()) return "Puerto no presente"
        return runCatching {
            FileOutputStream(device).use { fos ->
                fos.write(bytes)
                fos.flush()
            }
            "Enviado (${bytes.size}B)"
        }.getOrElse { err ->
            "Sin acceso root (${err.javaClass.simpleName})"
        }
    }

    private fun parseHexBytes(hex: String): ByteArray {
        val tokens = hex.trim().split(Regex("[\\s,;:-]+")).filter { it.isNotEmpty() }
        val result = ArrayList<Byte>(tokens.size)
        for (token in tokens) {
            val clean = token.removePrefix("0x").removePrefix("0X")
            val parsed = clean.toIntOrNull(16) ?: return ByteArray(0)
            result.add(parsed.toByte())
        }
        return result.toByteArray()
    }

    private fun parseVehicleExtras(prev: VehicleCanbusState, extras: Bundle): VehicleCanbusState {
        var next = prev.copy(lastUpdatedMs = System.currentTimeMillis())

        fun readBool(vararg keys: String, current: Boolean): Boolean {
            for (k in keys) {
                if (extras.containsKey(k)) {
                    @Suppress("DEPRECATION")
                    val v = extras.get(k)
                    return when (v) {
                        is Boolean -> v
                        is Number -> v.toInt() != 0
                        is String -> v == "1" || v.equals("true", ignoreCase = true)
                        else -> current
                    }
                }
            }
            return current
        }

        fun readFloat(vararg keys: String, current: Float): Float {
            for (k in keys) {
                if (extras.containsKey(k)) {
                    @Suppress("DEPRECATION")
                    val v = extras.get(k)
                    if (v is Number) return v.toFloat()
                    if (v is String) v.toFloatOrNull()?.let { return it }
                }
            }
            return current
        }

        // Claves estándar de puertas en radios TS / SYU / TW / Microntek
        next = next.copy(
            doorFrontLeftOpen = readBool("door_fl", "fl_door", "driver_door", current = next.doorFrontLeftOpen),
            doorFrontRightOpen = readBool("door_fr", "fr_door", "passenger_door", current = next.doorFrontRightOpen),
            doorRearLeftOpen = readBool("door_rl", "rl_door", current = next.doorRearLeftOpen),
            doorRearRightOpen = readBool("door_rr", "rr_door", current = next.doorRearRightOpen),
            trunkOpen = readBool("trunk", "door_trunk", "tailgate", current = next.trunkOpen),
            hoodOpen = readBool("hood", "door_hood", "bonnet", current = next.hoodOpen)
        )

        // Máscara de bits común en tramas CANBUS de puertas (door_status / door_mask)
        if (extras.containsKey("door_mask") || extras.containsKey("door_status")) {
            val mask = extras.getInt("door_mask", extras.getInt("door_status", 0))
            next = next.copy(
                doorFrontLeftOpen = (mask and 0x01) != 0,
                doorFrontRightOpen = (mask and 0x02) != 0,
                doorRearLeftOpen = (mask and 0x04) != 0,
                doorRearRightOpen = (mask and 0x08) != 0,
                trunkOpen = (mask and 0x10) != 0,
                hoodOpen = (mask and 0x20) != 0
            )
        }

        // Claves de TPMS en PSI (o conversión rápida si viene en kPa > 100)
        val fl = normalizePsi(readFloat("tpms_fl", "fl_pressure", current = next.tpmsFrontLeftPsi))
        val fr = normalizePsi(readFloat("tpms_fr", "fr_pressure", current = next.tpmsFrontRightPsi))
        val rl = normalizePsi(readFloat("tpms_rl", "rl_pressure", current = next.tpmsRearLeftPsi))
        val rr = normalizePsi(readFloat("tpms_rr", "rr_pressure", current = next.tpmsRearRightPsi))

        next = next.copy(
            tpmsFrontLeftPsi = fl,
            tpmsFrontRightPsi = fr,
            tpmsRearLeftPsi = rl,
            tpmsRearRightPsi = rr,
            tpmsFrontLeftAlert = readBool("tpms_fl_warn", current = fl < LOW_PSI_THRESHOLD || fl > HIGH_PSI_THRESHOLD),
            tpmsFrontRightAlert = readBool("tpms_fr_warn", current = fr < LOW_PSI_THRESHOLD || fr > HIGH_PSI_THRESHOLD),
            tpmsRearLeftAlert = readBool("tpms_rl_warn", current = rl < LOW_PSI_THRESHOLD || rl > HIGH_PSI_THRESHOLD),
            tpmsRearRightAlert = readBool("tpms_rr_warn", current = rr < LOW_PSI_THRESHOLD || rr > HIGH_PSI_THRESHOLD)
        )

        return next
    }

    private fun normalizePsi(raw: Float): Float {
        return if (raw > 100f) raw * 0.145038f else raw
    }

    private fun summarizeExtras(extras: Bundle?): String {
        if (extras == null || extras.isEmpty) return "(sin extras)"
        return extras.keySet().take(6).joinToString(", ") { key ->
            @Suppress("DEPRECATION")
            val v = extras.get(key)
            val formatted = when (v) {
                is ByteArray -> v.joinToString(" ") { b -> "%02X".format(b) }
                else -> v?.toString() ?: "null"
            }
            "$key=$formatted"
        }
    }

    private fun appendLog(entry: CanbusLogEntry) {
        synchronized(logBuffer) {
            logBuffer.add(0, entry)
            if (logBuffer.size > MAX_LOGS) {
                logBuffer.removeAt(logBuffer.lastIndex)
            }
        }
        notifyLogListeners()
    }

    private fun notifyStateListeners() {
        val snapshot = currentState
        listeners.forEach { it(snapshot) }
    }

    private fun notifyLogListeners() {
        val snapshot = getLogs()
        logListeners.forEach { it(snapshot) }
    }

    private const val MAX_LOGS = 100
    private const val LOW_PSI_THRESHOLD = 28.0f
    private const val HIGH_PSI_THRESHOLD = 42.0f
}
