package com.kaiyi.oemlauncher

import android.annotation.SuppressLint
import android.content.Context
import android.location.Location
import android.location.LocationListener
import android.location.LocationManager
import android.os.Bundle
import android.os.SystemClock

data class GpsTripTelemetry(
    val currentSpeedKmh: Int = 0,
    val distanceKm: Float = 0f,
    val elapsedSeconds: Long = 0L,
    val maxSpeedKmh: Int = 0,
    val avgSpeedKmh: Int = 0,
    val hasGpsFix: Boolean = false
)

/**
 * Velocímetro GPS en tiempo real (km/h) y Computadora de Viaje usando LocationManager.
 */
object TripComputerManager {

    private var locationManager: LocationManager? = null
    private var isTracking = false

    private var tripStartElapsedMs = SystemClock.elapsedRealtime()
    private var lastLocation: Location? = null
    private var totalDistanceMeters = 0f
    private var maxSpeedKmh = 0
    private var currentSpeedKmh = 0
    private var hasFix = false

    private val listeners = LinkedHashSet<(GpsTripTelemetry) -> Unit>()

    private val locationListener = object : LocationListener {
        override fun onLocationChanged(location: Location) {
            hasFix = true
            val speedKmh = if (location.hasSpeed()) {
                (location.speed * 3.6f).toInt().coerceAtLeast(0)
            } else {
                0
            }
            currentSpeedKmh = if (speedKmh < 2) 0 else speedKmh
            if (currentSpeedKmh > maxSpeedKmh) {
                maxSpeedKmh = currentSpeedKmh
            }

            val prev = lastLocation
            if (prev != null) {
                val delta = prev.distanceTo(location)
                if (delta in 1.5f..500f && location.accuracy <= 65f) {
                    totalDistanceMeters += delta
                }
            }
            lastLocation = location
            notifyListeners()
        }

        @Deprecated("Deprecated in Android API")
        override fun onStatusChanged(provider: String?, status: Int, extras: Bundle?) = Unit
        override fun onProviderEnabled(provider: String) = Unit
        override fun onProviderDisabled(provider: String) {
            hasFix = false
            currentSpeedKmh = 0
            notifyListeners()
        }
    }

    fun addListener(listener: (GpsTripTelemetry) -> Unit) {
        listeners.add(listener)
        listener(getSnapshot())
    }

    fun removeListener(listener: (GpsTripTelemetry) -> Unit) {
        listeners.remove(listener)
    }

    fun getSnapshot(): GpsTripTelemetry {
        val elapsedSec = ((SystemClock.elapsedRealtime() - tripStartElapsedMs) / 1000L).coerceAtLeast(0L)
        val distanceKm = totalDistanceMeters / 1000f
        val avgSpeed = if (elapsedSec > 5L) {
            ((distanceKm / (elapsedSec / 3600f))).toInt().coerceAtLeast(0)
        } else {
            0
        }
        return GpsTripTelemetry(
            currentSpeedKmh = currentSpeedKmh,
            distanceKm = distanceKm,
            elapsedSeconds = elapsedSec,
            maxSpeedKmh = maxSpeedKmh,
            avgSpeedKmh = avgSpeed,
            hasGpsFix = hasFix
        )
    }

    fun resetTrip() {
        tripStartElapsedMs = SystemClock.elapsedRealtime()
        totalDistanceMeters = 0f
        maxSpeedKmh = currentSpeedKmh
        lastLocation = null
        notifyListeners()
    }

    @SuppressLint("MissingPermission")
    fun startTracking(context: Context) {
        if (isTracking || !LocalAssetLoader.hasLocationPermission(context)) return
        val lm = context.applicationContext.getSystemService(Context.LOCATION_SERVICE) as? LocationManager
            ?: return
        locationManager = lm

        runCatching {
            if (lm.isProviderEnabled(LocationManager.GPS_PROVIDER)) {
                lm.requestLocationUpdates(LocationManager.GPS_PROVIDER, 1000L, 1f, locationListener)
            }
            if (lm.isProviderEnabled(LocationManager.NETWORK_PROVIDER)) {
                lm.requestLocationUpdates(LocationManager.NETWORK_PROVIDER, 3000L, 5f, locationListener)
            }
            isTracking = true
        }
    }

    fun stopTracking() {
        if (!isTracking) return
        runCatching {
            locationManager?.removeUpdates(locationListener)
        }
        isTracking = false
    }

    fun notifyTick() {
        notifyListeners()
    }

    private fun notifyListeners() {
        val snapshot = getSnapshot()
        listeners.forEach { it(snapshot) }
    }
}
