package com.kaiyi.oemlauncher

import android.animation.AnimatorSet
import android.animation.ObjectAnimator
import android.graphics.Bitmap
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.View
import android.view.animation.AccelerateDecelerateInterpolator
import android.view.animation.DecelerateInterpolator
import androidx.activity.OnBackPressedCallback
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import com.kaiyi.oemlauncher.databinding.ActivitySplashBinding

class SplashActivity : AppCompatActivity() {

    private lateinit var binding: ActivitySplashBinding
    private val mainHandler = Handler(Looper.getMainLooper())

    private var logoBitmap: Bitmap? = null
    private var introAnimatorSet: AnimatorSet? = null
    private var shineAnimatorSet: AnimatorSet? = null

    private val exitRunnable = Runnable {
        if (!isFinishing && !isDestroyed) {
            finish()
            @Suppress("DEPRECATION")
            overridePendingTransition(android.R.anim.fade_in, android.R.anim.fade_out)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivitySplashBinding.inflate(layoutInflater)
        setContentView(binding.root)

        enableFullscreenImmersive()

        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() = Unit
        })

        loadBrandLogo()
        binding.logoStage.post {
            startSplashChoreography()
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        mainHandler.removeCallbacks(exitRunnable)
        introAnimatorSet?.cancel()
        shineAnimatorSet?.cancel()
        logoBitmap?.recycle()
        logoBitmap = null
    }

    private fun loadBrandLogo() {
        val loader = LocalAssetLoader(this)
        loader.ensureLauncherDirectoryExists()
        val customLogo = loader.loadSplashLogoBitmap()
        if (customLogo != null) {
            logoBitmap = customLogo
            binding.ivSplashLogo.setImageBitmap(customLogo)
        } else {
            binding.ivSplashLogo.setImageResource(R.drawable.ic_brand_emblem_default)
        }
    }

    /**
     * Animación nativa de 2.5 segundos sobre fondo negro:
     * 0 ms – 1200 ms: Aparición (alpha 0 -> 1) + zoom suave (scale 0.85 -> 1.0)
     * 1200 ms – 2150 ms: Destello de luz diagonal cruzando el emblema
     * 2250 ms – 2500 ms: Transición hacia MainActivity
     */
    private fun startSplashChoreography() {
        val logo = binding.ivSplashLogo
        logo.alpha = 0f
        logo.scaleX = 0.85f
        logo.scaleY = 0.85f

        val alphaIn = ObjectAnimator.ofFloat(logo, View.ALPHA, 0f, 1f)
        val scaleXIn = ObjectAnimator.ofFloat(logo, View.SCALE_X, 0.85f, 1.0f)
        val scaleYIn = ObjectAnimator.ofFloat(logo, View.SCALE_Y, 0.85f, 1.0f)

        introAnimatorSet = AnimatorSet().apply {
            playTogether(alphaIn, scaleXIn, scaleYIn)
            duration = INTRO_DURATION_MS
            interpolator = DecelerateInterpolator(1.6f)
            start()
        }

        val stageWidth = binding.logoStage.width.toFloat().coerceAtLeast(340f)
        val shine = binding.viewDiagonalShine
        val startX = -shine.width.toFloat() - 40f
        val endX = stageWidth + 40f
        shine.translationX = startX
        shine.alpha = 0f

        val sweepX = ObjectAnimator.ofFloat(shine, View.TRANSLATION_X, startX, endX)
        val sweepAlpha = ObjectAnimator.ofFloat(shine, View.ALPHA, 0f, 0.92f, 0.92f, 0f)

        shineAnimatorSet = AnimatorSet().apply {
            playTogether(sweepX, sweepAlpha)
            startDelay = INTRO_DURATION_MS
            duration = SHINE_DURATION_MS
            interpolator = AccelerateDecelerateInterpolator()
            start()
        }

        binding.splashRoot.animate()
            .alpha(0f)
            .setStartDelay(TOTAL_SPLASH_MS - EXIT_FADE_MS)
            .setDuration(EXIT_FADE_MS)
            .start()

        mainHandler.postDelayed(exitRunnable, TOTAL_SPLASH_MS)
    }

    private fun enableFullscreenImmersive() {
        WindowCompat.setDecorFitsSystemWindows(window, false)
        WindowInsetsControllerCompat(window, binding.root).apply {
            hide(WindowInsetsCompat.Type.systemBars())
            systemBarsBehavior =
                WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
        }
    }

    companion object {
        private const val INTRO_DURATION_MS = 1200L
        private const val SHINE_DURATION_MS = 950L
        private const val EXIT_FADE_MS = 250L
        private const val TOTAL_SPLASH_MS = 2500L
    }
}
