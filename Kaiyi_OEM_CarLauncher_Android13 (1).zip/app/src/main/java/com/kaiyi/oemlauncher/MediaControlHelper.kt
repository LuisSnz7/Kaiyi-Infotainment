package com.kaiyi.oemlauncher

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.media.AudioManager
import android.os.Build
import android.os.SystemClock
import android.view.KeyEvent

data class MediaMetadataState(
    val title: String = "Audio del Vehículo",
    val artist: String = "Toca Play o abre Radio / Música",
    val isPlaying: Boolean = false
)

class MediaControlHelper(private val context: Context) {

    private val audioManager =
        context.getSystemService(Context.AUDIO_SERVICE) as AudioManager

    private var currentTitle: String = context.getString(R.string.media_default_title)
    private var currentArtist: String = context.getString(R.string.media_default_artist)
    private var metadataListener: ((MediaMetadataState) -> Unit)? = null
    private var metadataReceiver: BroadcastReceiver? = null

    fun isMusicActive(): Boolean = audioManager.isMusicActive

    fun getCurrentState(): MediaMetadataState {
        return MediaMetadataState(
            title = currentTitle,
            artist = currentArtist,
            isPlaying = isMusicActive()
        )
    }

    fun registerMetadataListener(listener: (MediaMetadataState) -> Unit) {
        metadataListener = listener
        if (metadataReceiver != null) {
            listener(getCurrentState())
            return
        }

        val filter = IntentFilter().apply {
            addAction("com.android.music.metachanged")
            addAction("com.android.music.playstatechanged")
            addAction("com.spotify.music.metadatachanged")
            addAction("com.spotify.music.playbackstatechanged")
            addAction("com.syu.radio.metachanged")
            addAction("com.ts.MainUI.media")
        }

        val receiver = object : BroadcastReceiver() {
            override fun onReceive(ctx: Context?, intent: Intent?) {
                if (intent == null) return
                val track = intent.getStringExtra("track")
                    ?: intent.getStringExtra("title")
                    ?: intent.getStringExtra("song")
                val artist = intent.getStringExtra("artist")
                    ?: intent.getStringExtra("album")
                    ?: intent.getStringExtra("station")

                if (!track.isNullOrBlank()) currentTitle = track
                if (!artist.isNullOrBlank()) currentArtist = artist
                metadataListener?.invoke(getCurrentState())
            }
        }

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            context.registerReceiver(receiver, filter, Context.RECEIVER_EXPORTED)
        } else {
            @Suppress("DEPRECATION")
            context.registerReceiver(receiver, filter)
        }
        metadataReceiver = receiver
        listener(getCurrentState())
    }

    fun unregisterMetadataListener() {
        metadataListener = null
        metadataReceiver?.let {
            runCatching { context.unregisterReceiver(it) }
        }
        metadataReceiver = null
    }

    fun sendPrevious() {
        dispatchMediaKey(KeyEvent.KEYCODE_MEDIA_PREVIOUS)
    }

    fun sendPlayPause() {
        dispatchMediaKey(KeyEvent.KEYCODE_MEDIA_PLAY_PAUSE)
    }

    fun sendNext() {
        dispatchMediaKey(KeyEvent.KEYCODE_MEDIA_NEXT)
    }

    private fun dispatchMediaKey(keyCode: Int) {
        val eventTime = SystemClock.uptimeMillis()
        val downEvent = KeyEvent(eventTime, eventTime, KeyEvent.ACTION_DOWN, keyCode, 0)
        val upEvent = KeyEvent(eventTime, eventTime + 20, KeyEvent.ACTION_UP, keyCode, 0)
        audioManager.dispatchMediaKeyEvent(downEvent)
        audioManager.dispatchMediaKeyEvent(upEvent)
    }
}
