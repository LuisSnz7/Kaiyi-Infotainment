package com.kaiyi.oemlauncher

import android.content.Intent
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.text.Editable
import android.text.TextWatcher
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import androidx.fragment.app.Fragment
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.kaiyi.oemlauncher.databinding.FragmentPageAppsBinding
import java.util.concurrent.Executors

class PageAppsFragment : Fragment() {

    private var _binding: FragmentPageAppsBinding? = null
    private val binding get() = _binding!!

    private lateinit var prefs: LauncherPrefs
    private lateinit var appResolver: AppResolver
    private lateinit var adapter: AppsDrawerAdapter

    private val executor = Executors.newSingleThreadExecutor()
    private val mainHandler = Handler(Looper.getMainLooper())
    private var allApps: List<InstalledApp> = emptyList()

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        _binding = FragmentPageAppsBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        val ctx = requireContext()
        prefs = LauncherPrefs(ctx)
        appResolver = AppResolver(ctx, prefs)

        adapter = AppsDrawerAdapter { app ->
            val launched = appResolver.launchPackage(app.packageName)
            if (!launched) {
                Toast.makeText(ctx, getString(R.string.msg_app_not_found, app.label), Toast.LENGTH_SHORT).show()
            }
        }

        binding.rvAppsGridPage.layoutManager =
            GridLayoutManager(ctx, 3, RecyclerView.HORIZONTAL, false)
        binding.rvAppsGridPage.setHasFixedSize(true)
        binding.rvAppsGridPage.adapter = adapter

        binding.btnPageAppsCanbus.setOnClickListener {
            startActivity(Intent(ctx, CanbusConsoleActivity::class.java))
        }

        binding.btnPageAppsSettings.setOnClickListener {
            appResolver.launchSystemSettings()
        }

        binding.etSearchAppsPage.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) = Unit
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {
                filterApps(s?.toString().orEmpty())
            }
            override fun afterTextChanged(s: Editable?) = Unit
        })

        loadAppsAsync()
    }

    override fun onResume() {
        super.onResume()
        if (allApps.isEmpty()) {
            loadAppsAsync()
        }
    }

    override fun onDestroyView() {
        super.onDestroyView()
        executor.shutdownNow()
        appResolver.clearIconCache()
        _binding = null
    }

    private fun loadAppsAsync() {
        executor.execute {
            val loaded = appResolver.getLaunchableApps(includeIcons = true)
            mainHandler.post {
                if (_binding == null || !isAdded) return@post
                allApps = loaded
                filterApps(binding.etSearchAppsPage.text?.toString().orEmpty())
            }
        }
    }

    private fun filterApps(query: String) {
        val trimmed = query.trim().lowercase()
        val filtered = if (trimmed.isEmpty()) {
            allApps
        } else {
            allApps.filter {
                it.label.lowercase().contains(trimmed) ||
                    it.packageName.lowercase().contains(trimmed)
            }
        }
        adapter.submitList(filtered)
        binding.tvEmptyAppsPage.visibility = if (filtered.isEmpty()) View.VISIBLE else View.GONE
    }
}
