package com.kaiyi.oemlauncher

import android.Manifest
import android.content.Context
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.os.Build
import android.os.Environment
import androidx.core.content.ContextCompat
import java.io.File

/**
 * Carga automáticamente las imágenes locales desde /storage/emulated/0/Pictures/KaiyiLauncher/
 * usando BitmapFactory.decodeFile() con submuestreo optimizado para radios Android 13 (2 GB RAM).
 */
class LocalAssetLoader(private val context: Context) {

    fun getLauncherFolder(): File {
        val fixedFolder = File(FIXED_FOLDER_PATH)
        if (fixedFolder.exists() || isPrimaryExternalPathWritable()) {
            return fixedFolder
        }
        val picturesDir = Environment.getExternalStoragePublicDirectory(
            Environment.DIRECTORY_PICTURES
        )
        return if (picturesDir != null) {
            File(picturesDir, FOLDER_NAME)
        } else {
            fixedFolder
        }
    }

    fun getFolderDisplayPath(): String = FIXED_FOLDER_PATH

    fun ensureLauncherDirectoryExists(): File {
        val folder = getLauncherFolder()
        if (!folder.exists()) {
            runCatching { folder.mkdirs() }
        }
        return folder
    }

    fun loadSplashLogoBitmap(): Bitmap? {
        return decodeFirstExistingFile(
            candidates = listOf("logo.jpg", "logo.png", "logo.jpeg"),
            maxWidth = MAX_LOGO_WIDTH,
            maxHeight = MAX_LOGO_HEIGHT
        )
    }

    fun loadVehicleFrontBitmap(): Bitmap? {
        return decodeFirstExistingFile(
            candidates = listOf("auto_frente.png", "auto_frente.jpg"),
            maxWidth = MAX_VEHICLE_WIDTH,
            maxHeight = MAX_VEHICLE_HEIGHT
        )
    }

    fun loadVehicleProfileBitmap(): Bitmap? {
        return decodeFirstExistingFile(
            candidates = listOf("auto_perfil.png", "auto_perfil.jpg"),
            maxWidth = MAX_VEHICLE_WIDTH,
            maxHeight = MAX_VEHICLE_HEIGHT
        )
    }

    private fun isPrimaryExternalPathWritable(): Boolean {
        return runCatching {
            val parent = File("/storage/emulated/0/Pictures")
            parent.exists() && parent.canRead()
        }.getOrDefault(false)
    }

    private fun decodeFirstExistingFile(
        candidates: List<String>,
        maxWidth: Int,
        maxHeight: Int
    ): Bitmap? {
        val folder = ensureLauncherDirectoryExists()
        for (name in candidates) {
            val file = File(folder, name)
            if (file.exists() && file.isFile && file.canRead() && file.length() > 0L) {
                val decoded = decodeSampledFile(file.absolutePath, maxWidth, maxHeight)
                if (decoded != null) return decoded
            }
        }
        return null
    }

    private fun decodeSampledFile(
        filePath: String,
        maxWidth: Int,
        maxHeight: Int
    ): Bitmap? {
        return runCatching {
            val boundsOpts = BitmapFactory.Options().apply {
                inJustDecodeBounds = true
            }
            BitmapFactory.decodeFile(filePath, boundsOpts)
            if (boundsOpts.outWidth <= 0 || boundsOpts.outHeight <= 0) {
                return@runCatching null
            }

            val decodeOpts = BitmapFactory.Options().apply {
                inSampleSize = calculateInSampleSize(
                    boundsOpts.outWidth,
                    boundsOpts.outHeight,
                    maxWidth,
                    maxHeight
                )
                inPreferredConfig = Bitmap.Config.ARGB_8888
            }
            BitmapFactory.decodeFile(filePath, decodeOpts)
        }.getOrNull()
    }

    private fun calculateInSampleSize(
        width: Int,
        height: Int,
        reqWidth: Int,
        reqHeight: Int
    ): Int {
        var inSampleSize = 1
        if (height > reqHeight || width > reqWidth) {
            val halfHeight = height / 2
            val halfWidth = width / 2
            while ((halfHeight / inSampleSize) >= reqHeight &&
                (halfWidth / inSampleSize) >= reqWidth
            ) {
                inSampleSize *= 2
            }
        }
        return inSampleSize
    }

    companion object {
        private const val FOLDER_NAME = "KaiyiLauncher"
        const val FIXED_FOLDER_PATH = "/storage/emulated/0/Pictures/KaiyiLauncher"

        private const val MAX_VEHICLE_WIDTH = 900
        private const val MAX_VEHICLE_HEIGHT = 500
        private const val MAX_LOGO_WIDTH = 640
        private const val MAX_LOGO_HEIGHT = 360

        fun hasReadStoragePermission(context: Context): Boolean {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R &&
                Environment.isExternalStorageManager()
            ) {
                return true
            }
            return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                ContextCompat.checkSelfPermission(
                    context,
                    Manifest.permission.READ_MEDIA_IMAGES
                ) == PackageManager.PERMISSION_GRANTED
            } else {
                ContextCompat.checkSelfPermission(
                    context,
                    Manifest.permission.READ_EXTERNAL_STORAGE
                ) == PackageManager.PERMISSION_GRANTED
            }
        }

        fun hasLocationPermission(context: Context): Boolean {
            val fine = ContextCompat.checkSelfPermission(
                context,
                Manifest.permission.ACCESS_FINE_LOCATION
            ) == PackageManager.PERMISSION_GRANTED
            val coarse = ContextCompat.checkSelfPermission(
                context,
                Manifest.permission.ACCESS_COARSE_LOCATION
            ) == PackageManager.PERMISSION_GRANTED
            return fine || coarse
        }

        fun hasAllFilesAccess(): Boolean {
            return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
                Environment.isExternalStorageManager()
            } else {
                true
            }
        }
    }
}
