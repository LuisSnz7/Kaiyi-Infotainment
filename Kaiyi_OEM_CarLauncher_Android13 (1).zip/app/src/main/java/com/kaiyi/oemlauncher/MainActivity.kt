package com.kaiyi.oemlauncher

import android.Manifest
import android.annotation.SuppressLint
import android.app.Activity
import android.bluetooth.BluetoothManager
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.media.AudioManager
import android.net.Uri
import android.net.wifi.WifiManager
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.view.MotionEvent
import android.view.View
import android.view.ViewConfiguration
import android.widget.ImageButton
import android.widget.SeekBar
import android.widget.Toast
import androidx.activity.OnBackPressedCallback
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import androidx.viewpager2.widget.ViewPager2
import com.kaiyi.oemlauncher.databinding.ActivityMainBinding
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding
    private lateinit var prefs: LauncherPrefs
    private lateinit var appResolver: AppResolver
    private lateinit var localAssetLoader: LocalAssetLoader
    private lateinit var audioManager: AudioManager

    private var isShadeOpen = false

    private val assignSlotLauncher = registerForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) { result ->
        if (result.resultCode == Activity.RESULT_OK) {
            supportFragmentManager.fragments.filterIsInstance<PageDrivingFragment>().forEach {
                it.refreshSlotLabelsAsync()
            }
        }
    }

    private val runtimePermissionsLauncher = registerForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions()
    ) { results ->
        val storageGranted = LocalAssetLoader.hasReadStoragePermission(this)
        if (storageGranted) {
            localAssetLoader.ensureLauncherDirectoryExists()
            supportFragmentManager.fragments.filterIsInstance<PageDrivingFragment>().forEach {
                it.reloadVehicleBitmaps()
            }
        } else if (results.isNotEmpty()) {
            Toast.makeText(this, R.string.msg_storage_permission_needed, Toast.LENGTH_LONG).show()
        }

        if (LocalAssetLoader.hasLocationPermission(this)) {
            TripComputerManager.startTracking(this)
        }
    }

    private val allFilesAccessLauncher = registerForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) {
        localAssetLoader.ensureLauncherDirectoryExists()
        supportFragmentManager.fragments.filterIsInstance<PageDrivingFragment>().forEach {
            it.reloadVehicleBitmaps()
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        enableFullscreenImmersive()

        prefs = LauncherPrefs(this)
        appResolver = AppResolver(this, prefs)
        localAssetLoader = LocalAssetLoader(this)
        audioManager = getSystemService(Context.AUDIO_SERVICE) as AudioManager

        localAssetLoader.ensureLauncherDirectoryExists()
        CanbusBridgeManager.startListening(this)

        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                when {
                    binding.nightClockOverlay.visibility == View.VISIBLE -> hideNightClockOverlay()
                    isShadeOpen -> closeTopShade()
                    binding.viewPagerMain.currentItem != 0 -> binding.viewPagerMain.setCurrentItem(0, true)
                }
            }
        })

        setupViewPager()
        setupBottomDock()
        setupTopPullDownShade()
        setupNightClockOverlay()
        requestRequiredRuntimePermissions()

        if (!hasShownBootSplash) {
            hasShownBootSplash = true
            startActivity(Intent(this, SplashActivity::class.java))
            @Suppress("DEPRECATION")
            overridePendingTransition(0, 0)
        }
    }

    override fun onResume() {
        super.onResume()
        enableFullscreenImmersive()
        syncShadeControls()
        if (LocalAssetLoader.hasLocationPermission(this)) {
            TripComputerManager.startTracking(this)
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        TripComputerManager.stopTracking()
        CanbusBridgeManager.stopListening(this)
        appResolver.clearIconCache()
    }

    private fun setupViewPager() {
        binding.viewPagerMain.adapter = MainPagerAdapter(this)
        binding.viewPagerMain.offscreenPageLimit = 2

        binding.viewPagerMain.registerOnPageChangeCallback(object : ViewPager2.OnPageChangeCallback() {
            override fun onPageSelected(position: Int) {
                super.onPageSelected(position)
                updatePageIndicators(position)
                updateDockPageHighlight(position)
            }
        })
        updatePageIndicators(0)
        updateDockPageHighlight(0)
    }

    private fun updatePageIndicators(activePage: Int) {
        val dots = listOf(binding.dotPage0, binding.dotPage1, binding.dotPage2)
        val density = resources.displayMetrics.density
        dots.forEachIndexed { index, view ->
            val isActive = index == activePage
            val params = view.layoutParams
            params.width = ((if (isActive) 24 else 10) * density).toInt()
            view.layoutParams = params
            view.setBackgroundColor(
                ContextCompat.getColor(
                    this,
                    if (isActive) R.color.oem_turquoise else R.color.status_disconnected
                )
            )
        }
    }

    private fun updateDockPageHighlight(activePage: Int) {
        highlightDockIcon(binding.btnDockHome, activePage == 0)
        highlightDockIcon(binding.btnDockApps, activePage == 1)
    }

    private fun highlightDockIcon(button: ImageButton, active: Boolean) {
        if (active) {
            button.setBackgroundResource(R.drawable.bg_dock_icon_active)
            button.setColorFilter(ContextCompat.getColor(this, R.color.oem_turquoise))
        } else {
            button.setBackgroundResource(0)
            button.setColorFilter(ContextCompat.getColor(this, R.color.text_primary))
        }
    }

    private fun setupBottomDock() {
        binding.btnDockHome.setOnClickListener {
            binding.viewPagerMain.setCurrentItem(0, true)
        }

        bindDockConfigurableSlot(binding.btnDockNav, LauncherSlot.MAPS)
        bindDockConfigurableSlot(binding.btnDockMusic, LauncherSlot.MUSIC)
        bindDockConfigurableSlot(binding.btnDockPhone, LauncherSlot.PHONE)
        bindDockConfigurableSlot(binding.btnDockZlink, LauncherSlot.ZLINK)

        binding.btnDockApps.setOnClickListener {
            binding.viewPagerMain.setCurrentItem(1, true)
        }
    }

    private fun bindDockConfigurableSlot(button: ImageButton, slot: LauncherSlot) {
        button.setOnClickListener {
            launchSlotWithFeedback(slot)
        }
        button.setOnLongClickListener {
            openAppPickerForSlot(slot)
            true
        }
    }

    fun launchSlotWithFeedback(slot: LauncherSlot) {
        val launched = appResolver.launchSlot(slot)
        if (!launched) {
            Toast.makeText(
                this,
                getString(R.string.msg_app_not_found, slot.defaultTitle),
                Toast.LENGTH_SHORT
            ).show()
            openAppPickerForSlot(slot)
        }
    }

    fun openAppPickerForSlot(slot: LauncherSlot) {
        val pickerIntent = Intent(this, AppsDrawerActivity::class.java).apply {
            putExtra(AppsDrawerActivity.EXTRA_ASSIGN_SLOT_KEY, slot.prefKey)
        }
        assignSlotLauncher.launch(pickerIntent)
    }

    @SuppressLint("ClickableViewAccessibility")
    private fun setupTopPullDownShade() {
        val touchSlop = ViewConfiguration.get(this).scaledTouchSlop
        val swipeOpenThreshold = touchSlop * 2f
        var downY = 0f
        var handledGesture = false

        binding.topSwipeHandleZone.setOnTouchListener { _, event ->
            when (event.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    downY = event.rawY
                    handledGesture = false
                    true
                }
                MotionEvent.ACTION_MOVE -> {
                    if (!handledGesture && (event.rawY - downY) > swipeOpenThreshold) {
                        handledGesture = true
                        openTopShade()
                    }
                    true
                }
                MotionEvent.ACTION_UP -> {
                    if (!handledGesture && kotlin.math.abs(event.rawY - downY) <= touchSlop) {
                        handledGesture = true
                        openTopShade()
                    }
                    true
                }
                else -> false
            }
        }

        binding.topShadeScrim.setOnClickListener { closeTopShade() }
        binding.btnCloseShadeHandle.setOnClickListener { closeTopShade() }

        binding.btnShadeCanbus.setOnClickListener {
            closeTopShade()
            startActivity(Intent(this, CanbusConsoleActivity::class.java))
        }

        binding.btnShadeNightClock.setOnClickListener {
            closeTopShade()
            showNightClockOverlay()
        }

        // Control real de Brillo de Pantalla
        binding.seekBrightness.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean) {
                if (!fromUser) return
                val clamped = progress.coerceIn(15, 255)
                binding.tvShadeBrightnessVal.text = "${(clamped * 100) / 255}%"
                applyScreenBrightness(clamped)
            }
            override fun onStartTrackingTouch(seekBar: SeekBar?) = Unit
            override fun onStopTrackingTouch(seekBar: SeekBar?) {
                if (!Settings.System.canWrite(this@MainActivity)) {
                    requestWriteSettingsPermission()
                }
            }
        })

        // Control real de Volumen Multimedia
        binding.seekVolume.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean) {
                if (!fromUser) return
                audioManager.setStreamVolume(AudioManager.STREAM_MUSIC, progress, 0)
                val max = audioManager.getStreamMaxVolume(AudioManager.STREAM_MUSIC).coerceAtLeast(1)
                binding.tvShadeVolumeVal.text = "${(progress * 100) / max}%"
            }
            override fun onStartTrackingTouch(seekBar: SeekBar?) = Unit
            override fun onStopTrackingTouch(seekBar: SeekBar?) = Unit
        })

        // Interruptor Wi-Fi
        binding.switchShadeWifi.setOnCheckedChangeListener { buttonView, isChecked ->
            if (!buttonView.isPressed) return@setOnCheckedChangeListener
            toggleWifi(isChecked)
        }

        // Interruptor Bluetooth
        binding.switchShadeBt.setOnCheckedChangeListener { buttonView, isChecked ->
            if (!buttonView.isPressed) return@setOnCheckedChangeListener
            toggleBluetooth(isChecked)
        }

        syncShadeControls()
    }

    private fun syncShadeControls() {
        val currentBrightness = runCatching {
            Settings.System.getInt(contentResolver, Settings.System.SCREEN_BRIGHTNESS)
        }.getOrDefault(200).coerceIn(15, 255)
        binding.seekBrightness.progress = currentBrightness
        binding.tvShadeBrightnessVal.text = "${(currentBrightness * 100) / 255}%"

        val maxVol = audioManager.getStreamMaxVolume(AudioManager.STREAM_MUSIC).coerceAtLeast(1)
        val curVol = audioManager.getStreamVolume(AudioManager.STREAM_MUSIC).coerceIn(0, maxVol)
        binding.seekVolume.max = maxVol
        binding.seekVolume.progress = curVol
        binding.tvShadeVolumeVal.text = "${(curVol * 100) / maxVol}%"

        val wifiManager = applicationContext.getSystemService(Context.WIFI_SERVICE) as? WifiManager
        binding.switchShadeWifi.isChecked = runCatching { wifiManager?.isWifiEnabled ?: false }.getOrDefault(false)

        val btManager = getSystemService(Context.BLUETOOTH_SERVICE) as? BluetoothManager
        val btAdapter = btManager?.adapter
        binding.switchShadeBt.isChecked = runCatching { btAdapter?.isEnabled ?: false }.getOrDefault(false)
    }

    private fun applyScreenBrightness(value0To255: Int) {
        val lp = window.attributes
        lp.screenBrightness = value0To255 / 255f
        window.attributes = lp

        if (Settings.System.canWrite(this)) {
            runCatching {
                Settings.System.putInt(
                    contentResolver,
                    Settings.System.SCREEN_BRIGHTNESS_MODE,
                    Settings.System.SCREEN_BRIGHTNESS_MODE_MANUAL
                )
                Settings.System.putInt(
                    contentResolver,
                    Settings.System.SCREEN_BRIGHTNESS,
                    value0To255
                )
            }
        }
    }

    private fun requestWriteSettingsPermission() {
        Toast.makeText(this, R.string.msg_write_settings_needed, Toast.LENGTH_SHORT).show()
        val intent = Intent(Settings.ACTION_MANAGE_WRITE_SETTINGS).apply {
            data = Uri.parse("package:$packageName")
        }
        runCatching { startActivity(intent) }
    }

    private fun toggleWifi(enable: Boolean) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            runCatching { startActivity(Intent(Settings.Panel.ACTION_WIFI)) }
        } else {
            val wm = applicationContext.getSystemService(Context.WIFI_SERVICE) as? WifiManager
            @Suppress("DEPRECATION")
            wm?.isWifiEnabled = enable
        }
    }

    private fun toggleBluetooth(enable: Boolean) {
        val btManager = getSystemService(Context.BLUETOOTH_SERVICE) as? BluetoothManager
        val adapter = btManager?.adapter
        val hasPerm = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            ContextCompat.checkSelfPermission(this, Manifest.permission.BLUETOOTH_CONNECT) ==
                PackageManager.PERMISSION_GRANTED
        } else {
            true
        }
        val toggled = if (hasPerm && adapter != null) {
            @Suppress("DEPRECATION")
            runCatching { if (enable) adapter.enable() else adapter.disable() }.getOrDefault(false)
        } else {
            false
        }
        if (!toggled) {
            runCatching { startActivity(Intent(Settings.ACTION_BLUETOOTH_SETTINGS)) }
        }
    }

    private fun openTopShade() {
        if (isShadeOpen) return
        isShadeOpen = true
        syncShadeControls()

        binding.topShadeScrim.visibility = View.VISIBLE
        binding.topShadeScrim.animate().alpha(1f).setDuration(200L).start()

        binding.topShadePanel.visibility = View.VISIBLE
        binding.topShadePanel.post {
            binding.topShadePanel.translationY = -binding.topShadePanel.height.toFloat()
            binding.topShadePanel.animate()
                .translationY(0f)
                .setDuration(240L)
                .start()
        }
    }

    private fun closeTopShade() {
        if (!isShadeOpen) return
        isShadeOpen = false

        binding.topShadeScrim.animate()
            .alpha(0f)
            .setDuration(180L)
            .withEndAction { binding.topShadeScrim.visibility = View.GONE }
            .start()

        binding.topShadePanel.animate()
            .translationY(-binding.topShadePanel.height.toFloat().coerceAtLeast(360f))
            .setDuration(200L)
            .withEndAction { binding.topShadePanel.visibility = View.GONE }
            .start()
    }

    private fun setupNightClockOverlay() {
        binding.nightClockOverlay.setOnClickListener {
            hideNightClockOverlay()
        }
    }

    private fun showNightClockOverlay() {
        val spanishLocale = Locale("es", "ES")
        val rawDate = SimpleDateFormat("EEEE, d 'de' MMMM", spanishLocale).format(Date())
        binding.tvNightClockDate.text = rawDate.replaceFirstChar {
            if (it.isLowerCase()) it.titlecase(spanishLocale) else it.toString()
        }
        binding.nightClockOverlay.alpha = 0f
        binding.nightClockOverlay.visibility = View.VISIBLE
        binding.nightClockOverlay.animate().alpha(1f).setDuration(240L).start()
    }

    private fun hideNightClockOverlay() {
        binding.nightClockOverlay.animate()
            .alpha(0f)
            .setDuration(180L)
            .withEndAction { binding.nightClockOverlay.visibility = View.GONE }
            .start()
    }

    private fun requestRequiredRuntimePermissions() {
        val permsToRequest = ArrayList<String>()
        if (!LocalAssetLoader.hasReadStoragePermission(this)) {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                permsToRequest.add(Manifest.permission.READ_MEDIA_IMAGES)
            } else {
                permsToRequest.add(Manifest.permission.READ_EXTERNAL_STORAGE)
            }
        }
        if (!LocalAssetLoader.hasLocationPermission(this)) {
            permsToRequest.add(Manifest.permission.ACCESS_FINE_LOCATION)
            permsToRequest.add(Manifest.permission.ACCESS_COARSE_LOCATION)
        }
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S &&
            ContextCompat.checkSelfPermission(this, Manifest.permission.BLUETOOTH_CONNECT) !=
            PackageManager.PERMISSION_GRANTED
        ) {
            permsToRequest.add(Manifest.permission.BLUETOOTH_CONNECT)
        }

        if (permsToRequest.isNotEmpty()) {
            runtimePermissionsLauncher.launch(permsToRequest.toTypedArray())
        } else {
            TripComputerManager.startTracking(this)
        }
    }

    fun openManageAllFilesPermission() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            val intent = Intent(
                Settings.ACTION_MANAGE_APP_ALL_FILES_ACCESS_PERMISSION,
                Uri.parse("package:$packageName")
            )
            val ok = runCatching { allFilesAccessLauncher.launch(intent) }.isSuccess
            if (!ok) {
                runCatching {
                    allFilesAccessLauncher.launch(Intent(Settings.ACTION_MANAGE_ALL_FILES_ACCESS_PERMISSION))
                }
            }
        } else {
            requestRequiredRuntimePermissions()
        }
    }

    private fun enableFullscreenImmersive() {
        WindowCompat.setDecorFitsSystemWindows(window, false)
        WindowInsetsControllerCompat(window, binding.root).apply {
            hide(WindowInsetsCompat.Type.systemBars())
            systemBarsBehavior =
                WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
        }
    }

    companion object {
        private var hasShownBootSplash = false
    }
}
