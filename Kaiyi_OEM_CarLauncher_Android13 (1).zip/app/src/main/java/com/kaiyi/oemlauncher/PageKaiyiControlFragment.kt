package com.kaiyi.oemlauncher

import android.content.Intent
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import androidx.fragment.app.Fragment
import com.kaiyi.oemlauncher.databinding.FragmentPageKaiyiControlBinding
import java.util.Locale

class PageKaiyiControlFragment : Fragment() {

    private var _binding: FragmentPageKaiyiControlBinding? = null
    private val binding get() = _binding!!

    private lateinit var prefs: LauncherPrefs
    private val mainHandler = Handler(Looper.getMainLooper())

    private val tripListener: (GpsTripTelemetry) -> Unit = { telemetry ->
        mainHandler.post {
            if (_binding != null && isAdded) {
                renderTripTelemetry(telemetry)
            }
        }
    }

    private val tripTickRunnable = object : Runnable {
        override fun run() {
            if (_binding != null && isAdded) {
                TripComputerManager.notifyTick()
                mainHandler.postDelayed(this, 1000L)
            }
        }
    }

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        _binding = FragmentPageKaiyiControlBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        val ctx = requireContext()
        prefs = LauncherPrefs(ctx)

        updateClusterButtonsHighlight(prefs.getActiveClusterTheme())

        binding.btnClusterClassic.setOnClickListener {
            triggerClusterTheme(ClusterThemeMode.CLASSIC)
        }
        binding.btnClusterSport.setOnClickListener {
            triggerClusterTheme(ClusterThemeMode.SPORT)
        }
        binding.btnClusterTech.setOnClickListener {
            triggerClusterTheme(ClusterThemeMode.TECH)
        }

        binding.btnTripReset.setOnClickListener {
            TripComputerManager.resetTrip()
        }

        binding.btnOpenNativeCarData.setOnClickListener {
            (activity as? MainActivity)?.launchSlotWithFeedback(LauncherSlot.CAR_DATA)
        }
        binding.btnOpenNativeCarData.setOnLongClickListener {
            (activity as? MainActivity)?.openAppPickerForSlot(LauncherSlot.CAR_DATA)
            true
        }

        binding.btnOpenCanbusConsole.setOnClickListener {
            startActivity(Intent(ctx, CanbusConsoleActivity::class.java))
        }
    }

    override fun onResume() {
        super.onResume()
        updateClusterButtonsHighlight(prefs.getActiveClusterTheme())
        TripComputerManager.addListener(tripListener)
        mainHandler.removeCallbacks(tripTickRunnable)
        mainHandler.postDelayed(tripTickRunnable, 1000L)
    }

    override fun onPause() {
        super.onPause()
        TripComputerManager.removeListener(tripListener)
        mainHandler.removeCallbacks(tripTickRunnable)
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }

    private fun triggerClusterTheme(mode: ClusterThemeMode) {
        val ctx = requireContext()
        val summary = CanbusBridgeManager.sendClusterThemeCommand(ctx, prefs, mode)
        updateClusterButtonsHighlight(mode)
        Toast.makeText(ctx, getString(R.string.msg_cluster_sent, summary), Toast.LENGTH_SHORT).show()
    }

    private fun updateClusterButtonsHighlight(activeMode: ClusterThemeMode) {
        binding.btnClusterClassic.setBackgroundResource(
            if (activeMode == ClusterThemeMode.CLASSIC) R.drawable.bg_cluster_card_active else R.drawable.bg_quick_tile
        )
        binding.btnClusterSport.setBackgroundResource(
            if (activeMode == ClusterThemeMode.SPORT) R.drawable.bg_cluster_card_active else R.drawable.bg_quick_tile
        )
        binding.btnClusterTech.setBackgroundResource(
            if (activeMode == ClusterThemeMode.TECH) R.drawable.bg_cluster_card_active else R.drawable.bg_quick_tile
        )
    }

    private fun renderTripTelemetry(telemetry: GpsTripTelemetry) {
        binding.tvTripDistance.text = String.format(Locale.US, "%.1f km", telemetry.distanceKm)
        binding.tvTripDuration.text = formatDuration(telemetry.elapsedSeconds)
        binding.tvTripMaxSpeed.text = "${telemetry.maxSpeedKmh} km/h"
        binding.tvTripAvgSpeed.text = "${telemetry.avgSpeedKmh} km/h"
    }

    private fun formatDuration(totalSeconds: Long): String {
        val hours = totalSeconds / 3600L
        val minutes = (totalSeconds % 3600L) / 60L
        val seconds = totalSeconds % 60L
        return String.format(Locale.US, "%02d:%02d:%02d", hours, minutes, seconds)
    }
}
