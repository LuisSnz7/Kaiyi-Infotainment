package com.kaiyi.oemlauncher

import android.Manifest
import android.bluetooth.BluetoothManager
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.location.LocationManager
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import android.widget.Toast
import androidx.core.content.ContextCompat
import androidx.fragment.app.Fragment
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import com.kaiyi.oemlauncher.databinding.FragmentPageDrivingBinding
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.concurrent.Executors

class PageDrivingFragment : Fragment() {

    private var _binding: FragmentPageDrivingBinding? = null
    private val binding get() = _binding!!

    private lateinit var prefs: LauncherPrefs
    private lateinit var appResolver: AppResolver
    private lateinit var mediaControlHelper: MediaControlHelper
    private lateinit var localAssetLoader: LocalAssetLoader

    private val executor = Executors.newSingleThreadExecutor()
    private val mainHandler = Handler(Looper.getMainLooper())

    private var isVehicleProfile = false
    private var isAnimatingVehicle = false
    private var frontBitmapCache: Bitmap? = null
    private var profileBitmapCache: Bitmap? = null

    private val canbusListener: (VehicleCanbusState) -> Unit = { state ->
        mainHandler.post {
            if (_binding != null && isAdded) {
                renderCanbusState(state)
            }
        }
    }

    private val gpsListener: (GpsTripTelemetry) -> Unit = { telemetry ->
        mainHandler.post {
            if (_binding != null && isAdded) {
                binding.tvGpsSpeed.text = telemetry.currentSpeedKmh.toString()
                binding.tvGpsFixStatus.text = getString(
                    if (telemetry.hasGpsFix) R.string.gps_active else R.string.gps_waiting
                )
            }
        }
    }

    private val statusPollRunnable = object : Runnable {
        override fun run() {
            if (_binding != null && isAdded) {
                updateSpanishDate()
                updateMediaStateUi()
                updateConnectivityStatus()
                mainHandler.postDelayed(this, 3500L)
            }
        }
    }

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        _binding = FragmentPageDrivingBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        val ctx = requireContext()
        prefs = LauncherPrefs(ctx)
        appResolver = AppResolver(ctx, prefs)
        mediaControlHelper = MediaControlHelper(ctx)
        localAssetLoader = LocalAssetLoader(ctx)

        setupVehicleShowcase()
        setupMediaPlayerCard()
        setupQuickAccessTiles()
        updateSpanishDate()
        refreshSlotLabelsAsync()

        mediaControlHelper.registerMetadataListener { state ->
            mainHandler.post {
                if (_binding != null && isAdded) {
                    binding.tvMediaTrackTitle.text = state.title
                    binding.tvMediaSubtitle.text = state.artist
                    updateMediaStateUi()
                }
            }
        }
    }

    override fun onResume() {
        super.onResume()
        CanbusBridgeManager.addStateListener(canbusListener)
        TripComputerManager.addListener(gpsListener)
        loadCustomVehicleBitmapsAsync()
        refreshSlotLabelsAsync()
        updateSpanishDate()
        updateConnectivityStatus()
        mainHandler.removeCallbacks(statusPollRunnable)
        mainHandler.postDelayed(statusPollRunnable, 3500L)
    }

    override fun onPause() {
        super.onPause()
        CanbusBridgeManager.removeStateListener(canbusListener)
        TripComputerManager.removeListener(gpsListener)
        mainHandler.removeCallbacks(statusPollRunnable)
    }

    override fun onDestroyView() {
        super.onDestroyView()
        mediaControlHelper.unregisterMetadataListener()
        executor.shutdownNow()
        frontBitmapCache?.recycle()
        profileBitmapCache?.recycle()
        frontBitmapCache = null
        profileBitmapCache = null
        _binding = null
    }

    private fun setupVehicleShowcase() {
        isVehicleProfile = prefs.isVehicleProfileView()
        applyCurrentVehicleImage()

        binding.ivVehicle.setOnClickListener {
            if (isAnimatingVehicle) return@setOnClickListener
            isAnimatingVehicle = true
            isVehicleProfile = !isVehicleProfile
            prefs.setVehicleProfileView(isVehicleProfile)

            binding.ivVehicle.animate()
                .alpha(0f)
                .setDuration(150L)
                .withEndAction {
                    if (_binding != null) {
                        applyCurrentVehicleImage()
                        binding.ivVehicle.animate()
                            .alpha(1f)
                            .setDuration(180L)
                            .withEndAction { isAnimatingVehicle = false }
                            .start()
                    } else {
                        isAnimatingVehicle = false
                    }
                }
                .start()
        }

        binding.ivVehicle.setOnLongClickListener {
            (activity as? MainActivity)?.launchSlotWithFeedback(LauncherSlot.CAR_DATA)
            true
        }

        binding.btnVehiclePhotoConfig.setOnClickListener {
            showVehicleOptionsDialog()
        }
    }

    fun reloadVehicleBitmaps() {
        if (_binding != null && isAdded) {
            loadCustomVehicleBitmapsAsync()
        }
    }

    private fun loadCustomVehicleBitmapsAsync() {
        executor.execute {
            localAssetLoader.ensureLauncherDirectoryExists()
            val front = localAssetLoader.loadVehicleFrontBitmap()
            val profile = localAssetLoader.loadVehicleProfileBitmap()
            mainHandler.post {
                if (_binding == null || !isAdded) {
                    front?.recycle()
                    profile?.recycle()
                    return@post
                }
                frontBitmapCache?.recycle()
                profileBitmapCache?.recycle()
                frontBitmapCache = front
                profileBitmapCache = profile
                applyCurrentVehicleImage()
            }
        }
    }

    private fun applyCurrentVehicleImage() {
        val customBitmap = if (isVehicleProfile) profileBitmapCache else frontBitmapCache
        if (customBitmap != null && !customBitmap.isRecycled) {
            binding.ivVehicle.setImageBitmap(customBitmap)
        } else {
            binding.ivVehicle.setImageResource(
                if (isVehicleProfile) R.drawable.auto_perfil else R.drawable.auto_frente
            )
        }
    }

    private fun renderCanbusState(state: VehicleCanbusState) {
        updateCornerBadge(
            container = binding.badgeFrontLeft,
            tvTpms = binding.tvTpmsFl,
            tvDoor = binding.tvDoorFl,
            doorCode = "DI",
            doorOpen = state.doorFrontLeftOpen,
            psi = state.tpmsFrontLeftPsi,
            tpmsAlert = state.tpmsFrontLeftAlert
        )
        updateCornerBadge(
            container = binding.badgeFrontRight,
            tvTpms = binding.tvTpmsFr,
            tvDoor = binding.tvDoorFr,
            doorCode = "DD",
            doorOpen = state.doorFrontRightOpen,
            psi = state.tpmsFrontRightPsi,
            tpmsAlert = state.tpmsFrontRightAlert
        )
        updateCornerBadge(
            container = binding.badgeRearLeft,
            tvTpms = binding.tvTpmsRl,
            tvDoor = binding.tvDoorRl,
            doorCode = "TI",
            doorOpen = state.doorRearLeftOpen,
            psi = state.tpmsRearLeftPsi,
            tpmsAlert = state.tpmsRearLeftAlert
        )
        updateCornerBadge(
            container = binding.badgeRearRight,
            tvTpms = binding.tvTpmsRr,
            tvDoor = binding.tvDoorRr,
            doorCode = "TD",
            doorOpen = state.doorRearRightOpen,
            psi = state.tpmsRearRightPsi,
            tpmsAlert = state.tpmsRearRightAlert
        )

        val openNames = ArrayList<String>()
        if (state.doorFrontLeftOpen) openNames.add("Del. Izq")
        if (state.doorFrontRightOpen) openNames.add("Del. Der")
        if (state.doorRearLeftOpen) openNames.add("Tras. Izq")
        if (state.doorRearRightOpen) openNames.add("Tras. Der")
        if (state.trunkOpen) openNames.add("Maletero")
        if (state.hoodOpen) openNames.add("Capó")

        if (openNames.isNotEmpty()) {
            binding.tvCanbusDoorSummary.text = "Abierto: ${openNames.joinToString(", ")}"
            binding.tvCanbusDoorSummary.setTextColor(
                ContextCompat.getColor(requireContext(), R.color.alert_danger)
            )
        } else if (state.anyTpmsAlert()) {
            binding.tvCanbusDoorSummary.text = "Alerta presión de neumáticos (TPMS)"
            binding.tvCanbusDoorSummary.setTextColor(
                ContextCompat.getColor(requireContext(), R.color.alert_warning)
            )
        } else {
            binding.tvCanbusDoorSummary.text = getString(R.string.doors_all_closed)
            binding.tvCanbusDoorSummary.setTextColor(
                ContextCompat.getColor(requireContext(), R.color.text_secondary)
            )
        }
    }

    private fun updateCornerBadge(
        container: View,
        tvTpms: TextView,
        tvDoor: TextView,
        doorCode: String,
        doorOpen: Boolean,
        psi: Float,
        tpmsAlert: Boolean
    ) {
        val ctx = requireContext()
        val hasAlert = doorOpen || tpmsAlert
        container.setBackgroundResource(
            if (hasAlert) R.drawable.bg_status_badge_alert else R.drawable.bg_status_badge_ok
        )
        tvTpms.text = String.format(Locale.US, "%.1f PSI", psi)
        tvTpms.setTextColor(
            ContextCompat.getColor(ctx, if (tpmsAlert) R.color.alert_warning else R.color.text_primary)
        )
        tvDoor.text = if (doorOpen) "$doorCode: ABIERTA" else "$doorCode: OK"
        tvDoor.setTextColor(
            ContextCompat.getColor(ctx, if (doorOpen) R.color.alert_danger else R.color.text_accent)
        )
    }

    private fun setupMediaPlayerCard() {
        binding.btnMediaPrev.setOnClickListener {
            mediaControlHelper.sendPrevious()
            pulseView(it)
            mainHandler.postDelayed({ if (_binding != null) updateMediaStateUi() }, 200L)
        }
        binding.btnMediaPlayPause.setOnClickListener {
            mediaControlHelper.sendPlayPause()
            pulseView(it)
            mainHandler.postDelayed({ if (_binding != null) updateMediaStateUi() }, 200L)
        }
        binding.btnMediaNext.setOnClickListener {
            mediaControlHelper.sendNext()
            pulseView(it)
            mainHandler.postDelayed({ if (_binding != null) updateMediaStateUi() }, 200L)
        }
    }

    private fun setupQuickAccessTiles() {
        bindTileSlot(binding.tileQuickRadio, LauncherSlot.RADIO)
        bindTileSlot(binding.tileQuickObd, LauncherSlot.OBD2)
        bindTileSlot(binding.tileQuickEqualizer, LauncherSlot.EQUALIZER)
        bindTileSlot(binding.tileQuickCarData, LauncherSlot.CAR_DATA)
    }

    private fun bindTileSlot(view: View, slot: LauncherSlot) {
        view.setOnClickListener {
            (activity as? MainActivity)?.launchSlotWithFeedback(slot)
        }
        view.setOnLongClickListener {
            (activity as? MainActivity)?.openAppPickerForSlot(slot)
            true
        }
    }

    fun refreshSlotLabelsAsync() {
        if (!isAdded || _binding == null) return
        executor.execute {
            val apps = appResolver.getLaunchableApps(includeIcons = false)
            val radio = appResolver.resolvePackageForSlot(LauncherSlot.RADIO, apps)
            val obd = appResolver.resolvePackageForSlot(LauncherSlot.OBD2, apps)
            val eq = appResolver.resolvePackageForSlot(LauncherSlot.EQUALIZER, apps)
            val carData = appResolver.resolvePackageForSlot(LauncherSlot.CAR_DATA, apps)

            mainHandler.post {
                if (_binding == null || !isAdded) return@post
                binding.tvTileRadio.text = radio?.label ?: getString(R.string.label_radio)
                binding.tvTileObd.text = obd?.label ?: getString(R.string.label_obd2)
                binding.tvTileEqualizer.text = eq?.label ?: getString(R.string.label_equalizer)
                binding.tvTileCarData.text = carData?.label ?: getString(R.string.label_car_data)
            }
        }
    }

    private fun showVehicleOptionsDialog() {
        val ctx = requireContext()
        val folderPath = localAssetLoader.getFolderDisplayPath()
        val options = arrayOf(
            getString(R.string.vehicle_opt_reload_folder),
            getString(R.string.vehicle_opt_grant_storage),
            getString(R.string.vehicle_opt_canbus_console),
            getString(R.string.vehicle_opt_preview_splash)
        )

        MaterialAlertDialogBuilder(ctx)
            .setTitle(R.string.vehicle_menu_title)
            .setItems(options) { _, which ->
                when (which) {
                    0 -> {
                        loadCustomVehicleBitmapsAsync()
                        Toast.makeText(
                            ctx,
                            getString(R.string.msg_folder_hint, folderPath),
                            Toast.LENGTH_LONG
                        ).show()
                    }
                    1 -> (activity as? MainActivity)?.openManageAllFilesPermission()
                    2 -> startActivity(Intent(ctx, CanbusConsoleActivity::class.java))
                    3 -> startActivity(Intent(ctx, SplashActivity::class.java))
                }
            }
            .setNegativeButton(android.R.string.cancel, null)
            .show()
    }

    private fun updateSpanishDate() {
        val spanishLocale = Locale("es", "ES")
        val formatter = SimpleDateFormat("EEEE, d 'de' MMMM", spanishLocale)
        val rawDate = formatter.format(Date())
        binding.textDateSpanish.text = rawDate.replaceFirstChar {
            if (it.isLowerCase()) it.titlecase(spanishLocale) else it.toString()
        }
    }

    private fun updateMediaStateUi() {
        val isActive = mediaControlHelper.isMusicActive()
        binding.btnMediaPlayPause.setImageResource(
            if (isActive) R.drawable.ic_pause else R.drawable.ic_play
        )
        binding.tvMediaStateBadge.text = getString(
            if (isActive) R.string.media_status_active else R.string.media_status_idle
        )
        binding.tvMediaStateBadge.setTextColor(
            ContextCompat.getColor(
                requireContext(),
                if (isActive) R.color.oem_turquoise else R.color.text_secondary
            )
        )
    }

    private fun updateConnectivityStatus() {
        val ctx = requireContext()
        val wifiConnected = isWifiConnected(ctx)
        val btEnabled = isBluetoothEnabled(ctx)
        val gpsEnabled = isGpsEnabled(ctx)

        applyStatusTint(binding.ivStatusWifi, binding.tvStatusWifi, wifiConnected)
        applyStatusTint(binding.ivStatusBluetooth, binding.tvStatusBluetooth, btEnabled)
        applyStatusTint(binding.ivStatusGps, binding.tvStatusGps, gpsEnabled)
    }

    private fun applyStatusTint(icon: ImageView, label: TextView, active: Boolean) {
        val ctx = requireContext()
        icon.setColorFilter(
            ContextCompat.getColor(ctx, if (active) R.color.status_connected else R.color.status_disconnected)
        )
        label.setTextColor(
            ContextCompat.getColor(ctx, if (active) R.color.text_accent else R.color.text_secondary)
        )
    }

    private fun isWifiConnected(ctx: Context): Boolean {
        val cm = ctx.getSystemService(Context.CONNECTIVITY_SERVICE) as? ConnectivityManager ?: return false
        val network = cm.activeNetwork ?: return false
        val caps = cm.getNetworkCapabilities(network) ?: return false
        return caps.hasTransport(NetworkCapabilities.TRANSPORT_WIFI)
    }

    private fun isBluetoothEnabled(ctx: Context): Boolean {
        val btManager = ctx.getSystemService(Context.BLUETOOTH_SERVICE) as? BluetoothManager
        val adapter = btManager?.adapter ?: return false
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            val granted = ContextCompat.checkSelfPermission(
                ctx,
                Manifest.permission.BLUETOOTH_CONNECT
            ) == PackageManager.PERMISSION_GRANTED
            if (!granted) return false
        }
        return runCatching { adapter.isEnabled }.getOrDefault(false)
    }

    private fun isGpsEnabled(ctx: Context): Boolean {
        val lm = ctx.getSystemService(Context.LOCATION_SERVICE) as? LocationManager ?: return false
        return runCatching { lm.isProviderEnabled(LocationManager.GPS_PROVIDER) }.getOrDefault(false)
    }

    private fun pulseView(view: View) {
        view.animate()
            .scaleX(0.92f)
            .scaleY(0.92f)
            .setDuration(80L)
            .withEndAction {
                view.animate().scaleX(1f).scaleY(1f).setDuration(120L).start()
            }
            .start()
    }
}
