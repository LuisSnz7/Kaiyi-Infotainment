package com.kaiyi.oemlauncher

import android.content.Context
import android.content.SharedPreferences

enum class ClusterThemeMode(
    val id: String,
    val displayName: String,
    val defaultAction: String,
    val defaultExtraKey: String,
    val defaultExtraValue: String,
    val defaultSerialPort: String,
    val defaultHexFrame: String
) {
    CLASSIC(
        id = "classic",
        displayName = "Modo Clásico",
        defaultAction = "com.ts.canbus.CMD",
        defaultExtraKey = "cluster_theme",
        defaultExtraValue = "1",
        defaultSerialPort = "/dev/ttyS1",
        defaultHexFrame = "AA 55 03 81 01 01"
    ),
    SPORT(
        id = "sport",
        displayName = "Modo Sport",
        defaultAction = "com.ts.canbus.CMD",
        defaultExtraKey = "cluster_theme",
        defaultExtraValue = "2",
        defaultSerialPort = "/dev/ttyS1",
        defaultHexFrame = "AA 55 03 81 02 02"
    ),
    TECH(
        id = "tech",
        displayName = "Modo Tech",
        defaultAction = "com.ts.canbus.CMD",
        defaultExtraKey = "cluster_theme",
        defaultExtraValue = "3",
        defaultSerialPort = "/dev/ttyS1",
        defaultHexFrame = "AA 55 03 81 03 03"
    );

    companion object {
        fun fromId(id: String?): ClusterThemeMode {
            return values().firstOrNull { it.id == id } ?: TECH
        }
    }
}

data class ClusterCommandConfig(
    val mode: ClusterThemeMode,
    val broadcastAction: String,
    val targetPackage: String,
    val extraKey: String,
    val extraValue: String,
    val serialPortPath: String,
    val hexPayload: String
)

class LauncherPrefs(context: Context) {

    private val prefs: SharedPreferences =
        context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)

    fun getAssignedPackage(slot: LauncherSlot): String? {
        return prefs.getString(slot.prefKey, null)
    }

    fun setAssignedPackage(slot: LauncherSlot, packageName: String) {
        prefs.edit().putString(slot.prefKey, packageName).apply()
    }

    fun clearAssignedPackage(slot: LauncherSlot) {
        prefs.edit().remove(slot.prefKey).apply()
    }

    fun isVehicleProfileView(): Boolean {
        return prefs.getBoolean(KEY_VEHICLE_PROFILE, false)
    }

    fun setVehicleProfileView(isProfile: Boolean) {
        prefs.edit().putBoolean(KEY_VEHICLE_PROFILE, isProfile).apply()
    }

    fun getActiveClusterTheme(): ClusterThemeMode {
        return ClusterThemeMode.fromId(prefs.getString(KEY_ACTIVE_CLUSTER_THEME, ClusterThemeMode.TECH.id))
    }

    fun setActiveClusterTheme(mode: ClusterThemeMode) {
        prefs.edit().putString(KEY_ACTIVE_CLUSTER_THEME, mode.id).apply()
    }

    fun getClusterCommandConfig(mode: ClusterThemeMode): ClusterCommandConfig {
        val prefix = "canbus_${mode.id}_"
        return ClusterCommandConfig(
            mode = mode,
            broadcastAction = prefs.getString("${prefix}action", mode.defaultAction).orEmpty()
                .ifBlank { mode.defaultAction },
            targetPackage = prefs.getString("${prefix}pkg", "").orEmpty(),
            extraKey = prefs.getString("${prefix}extra_key", mode.defaultExtraKey).orEmpty()
                .ifBlank { mode.defaultExtraKey },
            extraValue = prefs.getString("${prefix}extra_val", mode.defaultExtraValue).orEmpty()
                .ifBlank { mode.defaultExtraValue },
            serialPortPath = prefs.getString("${prefix}serial_port", mode.defaultSerialPort).orEmpty(),
            hexPayload = prefs.getString("${prefix}hex_payload", mode.defaultHexFrame).orEmpty()
        )
    }

    fun saveClusterCommandConfig(config: ClusterCommandConfig) {
        val prefix = "canbus_${config.mode.id}_"
        prefs.edit()
            .putString("${prefix}action", config.broadcastAction.trim())
            .putString("${prefix}pkg", config.targetPackage.trim())
            .putString("${prefix}extra_key", config.extraKey.trim())
            .putString("${prefix}extra_val", config.extraValue.trim())
            .putString("${prefix}serial_port", config.serialPortPath.trim())
            .putString("${prefix}hex_payload", config.hexPayload.trim())
            .apply()
    }

    companion object {
        private const val PREFS_NAME = "kaiyi_oem_launcher_prefs"
        private const val KEY_VEHICLE_PROFILE = "vehicle_view_profile"
        private const val KEY_ACTIVE_CLUSTER_THEME = "active_cluster_theme"
    }
}
