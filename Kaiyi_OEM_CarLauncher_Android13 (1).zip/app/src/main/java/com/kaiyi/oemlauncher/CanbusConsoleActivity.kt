package com.kaiyi.oemlauncher

import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.LayoutInflater
import android.view.ViewGroup
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.kaiyi.oemlauncher.databinding.ActivityCanbusConsoleBinding
import com.kaiyi.oemlauncher.databinding.ItemCanbusLogBinding

class CanbusConsoleActivity : AppCompatActivity() {

    private lateinit var binding: ActivityCanbusConsoleBinding
    private lateinit var prefs: LauncherPrefs
    private lateinit var logAdapter: CanbusLogAdapter

    private val mainHandler = Handler(Looper.getMainLooper())
    private var editingMode: ClusterThemeMode = ClusterThemeMode.TECH

    private val logListener: (List<CanbusLogEntry>) -> Unit = { entries ->
        mainHandler.post {
            logAdapter.submitList(entries)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityCanbusConsoleBinding.inflate(layoutInflater)
        setContentView(binding.root)

        enableFullscreenImmersive()
        prefs = LauncherPrefs(this)

        binding.btnCanbusBack.setOnClickListener { finish() }

        binding.btnSimulateDoorTpms.setOnClickListener {
            CanbusBridgeManager.simulateDoorAndTpmsAlert()
        }

        binding.btnClearCanbusLogs.setOnClickListener {
            CanbusBridgeManager.clearLogs()
        }

        val detected = CanbusBridgeManager.scanInstalledCanbusPackages(this)
        binding.tvDetectedCanbusPackages.text = if (detected.isEmpty()) {
            "No se detectaron paquetes CANBUS de fábrica; escuchando broadcasts globales."
        } else {
            detected.joinToString(" · ")
        }

        logAdapter = CanbusLogAdapter()
        binding.rvCanbusLogs.layoutManager = LinearLayoutManager(this)
        binding.rvCanbusLogs.adapter = logAdapter

        binding.btnSelectModeClassic.setOnClickListener { loadModeIntoForm(ClusterThemeMode.CLASSIC) }
        binding.btnSelectModeSport.setOnClickListener { loadModeIntoForm(ClusterThemeMode.SPORT) }
        binding.btnSelectModeTech.setOnClickListener { loadModeIntoForm(ClusterThemeMode.TECH) }

        binding.btnSaveCanbusConfig.setOnClickListener {
            saveCurrentForm()
            Toast.makeText(this, "Vínculo guardado para ${editingMode.displayName}", Toast.LENGTH_SHORT).show()
        }

        binding.btnTestCanbusSend.setOnClickListener {
            saveCurrentForm()
            val summary = CanbusBridgeManager.sendClusterThemeCommand(this, prefs, editingMode)
            Toast.makeText(this, summary, Toast.LENGTH_SHORT).show()
        }

        loadModeIntoForm(prefs.getActiveClusterTheme())
    }

    override fun onResume() {
        super.onResume()
        enableFullscreenImmersive()
        CanbusBridgeManager.addLogListener(logListener)
    }

    override fun onPause() {
        super.onPause()
        CanbusBridgeManager.removeLogListener(logListener)
    }

    private fun loadModeIntoForm(mode: ClusterThemeMode) {
        editingMode = mode
        val config = prefs.getClusterCommandConfig(mode)

        binding.etCanbusAction.setText(config.broadcastAction)
        binding.etCanbusTargetPkg.setText(config.targetPackage)
        binding.etCanbusExtraKey.setText(config.extraKey)
        binding.etCanbusExtraVal.setText(config.extraValue)
        binding.etCanbusSerialPort.setText(config.serialPortPath)
        binding.etCanbusHexPayload.setText(config.hexPayload)

        val activeColor = ContextCompat.getColor(this, R.color.oem_turquoise)
        val idleColor = ContextCompat.getColor(this, R.color.text_secondary)
        binding.btnSelectModeClassic.setTextColor(if (mode == ClusterThemeMode.CLASSIC) activeColor else idleColor)
        binding.btnSelectModeSport.setTextColor(if (mode == ClusterThemeMode.SPORT) activeColor else idleColor)
        binding.btnSelectModeTech.setTextColor(if (mode == ClusterThemeMode.TECH) activeColor else idleColor)
    }

    private fun saveCurrentForm() {
        val config = ClusterCommandConfig(
            mode = editingMode,
            broadcastAction = binding.etCanbusAction.text?.toString().orEmpty()
                .ifBlank { editingMode.defaultAction },
            targetPackage = binding.etCanbusTargetPkg.text?.toString().orEmpty(),
            extraKey = binding.etCanbusExtraKey.text?.toString().orEmpty()
                .ifBlank { editingMode.defaultExtraKey },
            extraValue = binding.etCanbusExtraVal.text?.toString().orEmpty()
                .ifBlank { editingMode.defaultExtraValue },
            serialPortPath = binding.etCanbusSerialPort.text?.toString().orEmpty(),
            hexPayload = binding.etCanbusHexPayload.text?.toString().orEmpty()
        )
        prefs.saveClusterCommandConfig(config)
    }

    private fun enableFullscreenImmersive() {
        WindowCompat.setDecorFitsSystemWindows(window, false)
        WindowInsetsControllerCompat(window, binding.root).apply {
            hide(WindowInsetsCompat.Type.systemBars())
            systemBarsBehavior =
                WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
        }
    }

    private class CanbusLogAdapter : RecyclerView.Adapter<CanbusLogAdapter.LogHolder>() {
        private val items = ArrayList<CanbusLogEntry>()

        fun submitList(newItems: List<CanbusLogEntry>) {
            items.clear()
            items.addAll(newItems)
            notifyDataSetChanged()
        }

        override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): LogHolder {
            val binding = ItemCanbusLogBinding.inflate(
                LayoutInflater.from(parent.context),
                parent,
                false
            )
            return LogHolder(binding)
        }

        override fun onBindViewHolder(holder: LogHolder, position: Int) {
            holder.bind(items[position])
        }

        override fun getItemCount(): Int = items.size

        class LogHolder(
            private val binding: ItemCanbusLogBinding
        ) : RecyclerView.ViewHolder(binding.root) {
            fun bind(entry: CanbusLogEntry) {
                binding.tvLogDirection.text = "[${entry.direction} ${entry.timestamp}]"
                binding.tvLogAction.text = entry.action
                binding.tvLogDetail.text = entry.detail
            }
        }
    }
}
